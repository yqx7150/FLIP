from torch.utils.data import DataLoader, Subset, Dataset
import torchvision.transforms as transforms
import torchvision.transforms as T
import cv2
import glob
import matplotlib.pyplot as plt
import numpy as np
import time
import torch
import os
import torch.nn.functional as F
import torch.fft as fft


class LoadDataset(Dataset):
    def __init__(self, file_list, transform=None):
        self.files = glob.glob(file_list + '/*.png')  # church
        '''
        self.folders = glob.glob(file_list+ '/*')
        self.files=[]
        for folder in self.folders:
            for f in glob.glob(folder+'/*.png'):
                self.files.append(f)
        '''

        self.transform = transform
        self.to_tensor = T.ToTensor()

    def __len__(self):
        return len(self.files)

    def __getitem__(self, index):
        def MyAdjointOperatorPropagation(I, H):
            # 计算二维傅里叶变换并移动低频到中心
            FI = fft.fftshift(fft.fft2(fft.fftshift(I)))

            # 在频域中执行逆操作
            Or = fft.fftshift(fft.ifft2(fft.fftshift(FI / H)))

            # 取实部
            Or = torch.real(Or)

            # 可选归一化
            # Or = Or / torch.max(Or)

            return Or

        def pinhole(O, di, x, y, z, Lx, dp, Nx):
            if O.ndim == 3:  # 如果是彩色图像，则转为灰度图像
                O = cv2.cvtColor((O * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY) / 255.0

            m, n = O.shape
            Ly = m * Lx / n  # 计算物体高度

            M = di / z  # 放大倍率
            Lxi = M * Lx  # 图像宽度
            Lyi = M * Ly  # 图像高度

            # 计算传感器的物理尺寸
            W = Nx * dp
            H = Nx * dp

            # 计算缩放后的物体坐标
            Xs, Ys = np.meshgrid(np.linspace(-Lxi / 2, Lxi / 2, n),
                                 np.linspace(-Lyi / 2, Lyi / 2, m))

            # 计算映射的目标坐标
            Xq, Yq = np.meshgrid(np.linspace(-W / 2, W / 2, Nx),
                                 np.linspace(-H / 2, H / 2, Nx))

            # 归一化坐标 (-1,1)
            Xq_norm = 2 * (Xq - Xs.min()) / (Xs.max() - Xs.min()) - 1
            Yq_norm = 2 * (Yq - Ys.min()) / (Ys.max() - Ys.min()) - 1

            # 生成 PyTorch 张量
            O_tensor = torch.tensor(O, dtype=torch.float32).unsqueeze(0).unsqueeze(0)  # [1, 1, m, n]
            grid = torch.stack((torch.tensor(Xq_norm, dtype=torch.float32), torch.tensor(Yq_norm, dtype=torch.float32)),
                               dim=-1).unsqueeze(0)  # [1, Nx, Nx, 2]

            # 使用 PyTorch 进行插值
            I = F.grid_sample(O_tensor, grid, mode='bilinear', padding_mode='zeros', align_corners=True)

            return I.squeeze().numpy()

        def convolve2D(image, kernel, device='cuda' if torch.cuda.is_available() else 'cpu'):
            # 确保数据在 GPU 上
            image_tensor = torch.tensor(image, dtype=torch.float32, device=device).unsqueeze(0).unsqueeze(0)
            kernel_tensor = torch.tensor(kernel, dtype=torch.float32, device=device).unsqueeze(0).unsqueeze(0)

            # 归一化 kernel 避免计算误差
            kernel_tensor /= kernel_tensor.sum() + 1e-8

            # 执行 GPU 加速卷积
            output = F.conv2d(image_tensor, kernel_tensor,
                              padding=(kernel_tensor.shape[-2] // 2, kernel_tensor.shape[-1] // 2))

            return output.squeeze()  # **这里不转换回 NumPy，而是保持 PyTorch Tensor**

        def FZA(S, N, r1, phi):
            x_line = np.linspace(-S / 2, S / 2 - S / N, N)
            y_line = np.linspace(-S / 2, S / 2 - S / N, N)
            x, y = np.meshgrid(x_line, y_line)
            r_2 = x ** 2 + y ** 2
            mask = 0.5 * (1 + np.cos(np.pi * r_2 / r1 ** 2 + phi))
            return (mask > 0.5).astype(float)



        def process_channel(Im, mask, dp, ri, device='cuda' if torch.cuda.is_available() else 'cpu'):
            # 确保输入数据为 PyTorch Tensor 并在 GPU 上
            Im_tensor = torch.tensor(Im, dtype=torch.float32, device=device)
            mask_tensor = torch.tensor(mask, dtype=torch.float32, device=device)

            # **调用 convolve2D() 并确保结果仍然是 PyTorch Tensor**
            result = convolve2D(Im_tensor, mask_tensor, device) * (2 * dp * dp / ri ** 2)

            # **在 GPU 上完成归一化**
            result_min = result.min()
            result_max = result.max()
            normalized_result = (result - result_min) / (result_max - result_min + 1e-8)

            return normalized_result.cpu().numpy()  # **仅在最终返回时转换为 NumPy**

        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        # 读取彩色图片
        img = cv2.imread(self.files[index], 3)
        img = cv2.resize(img, (256, 256))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) / 255.0
        di = 3  # the distance from mask to sensor
        z1 = 220
        x1 = 0
        y1 = 0
        Lx1 = 205  # object size
        dp = 0.014  # pixel pitch
        Nx, Ny = 256, 256  # pixel numbers

        # 计算光阑直径和 FZA 相关参数
        S = 2 * dp * Nx  # aperture diameter
        r1 = 0.23  # FZA constant
        M = di / z1
        ri = (1 + M) * r1

        phi_values = [0 * np.pi, 0.25 * np.pi, 0.5 * np.pi, 0.75 * np.pi]

        # 生成 FZA 掩模
        mask1, mask2, mask3, mask4 = [FZA(S, 2 * Nx, ri, phi) for phi in phi_values]

        # 分离彩色通道
        R, G, B = img[:, :, 0], img[:, :, 1], img[:, :, 2]

        # 生成每个通道的成像
        ImR = pinhole(R, di, x1, y1, z1, Lx1, dp, Nx)
        ImG = pinhole(G, di, x1, y1, z1, Lx1, dp, Nx)
        ImB = pinhole(B, di, x1, y1, z1, Lx1, dp, Nx)

        # 处理四个相位的通道数据，并归一化

        I1 = np.stack((process_channel(ImR, mask1, dp, ri),
                       process_channel(ImG, mask1, dp, ri),
                       process_channel(ImB, mask1, dp, ri)), axis=-1)

        I2 = np.stack((process_channel(ImR, mask2, dp, ri),
                       process_channel(ImG, mask2, dp, ri),
                       process_channel(ImB, mask2, dp, ri)), axis=-1)

        I3 = np.stack((process_channel(ImR, mask3, dp, ri),
                       process_channel(ImG, mask3, dp, ri),
                       process_channel(ImB, mask3, dp, ri)), axis=-1)

        I4 = np.stack((process_channel(ImR, mask4, dp, ri),
                       process_channel(ImG, mask4, dp, ri),
                       process_channel(ImB, mask4, dp, ri)), axis=-1)

        I1 = torch.tensor(I1, dtype=torch.float32, device=device)
        I2 = torch.tensor(I2, dtype=torch.float32, device=device)
        I3 = torch.tensor(I3, dtype=torch.float32, device=device)
        I4 = torch.tensor(I4, dtype=torch.float32, device=device)

        # 计算傅里叶域参数
        M = di / z1
        ri = (1 + M) * r1
        fu_max = 0.5 / dp
        fv_max = 0.5 / dp
        du = 2 * fu_max / Nx
        dv = 2 * fv_max / Ny
        # 添加 indexing='ij' 参数
        u, v = torch.meshgrid(torch.arange(-fu_max, fu_max, du, device='cuda'),
                              torch.arange(-fv_max, fv_max, dv, device='cuda'),
                              indexing='ij')

        H1 = 1j * torch.exp(1j * (-(torch.pi * ri ** 2) * (u ** 2 + v ** 2)))
        H2 = 1j * torch.exp(1j * (-(torch.pi * ri ** 2) * (u ** 2 + v ** 2) + 0.25 * torch.pi))
        H3 = 1j * torch.exp(1j * (-(torch.pi * ri ** 2) * (u ** 2 + v ** 2) + 0.5 * torch.pi))
        H4 = 1j * torch.exp(1j * (-(torch.pi * ri ** 2) * (u ** 2 + v ** 2) + 0.75 * torch.pi))

        I1_R = I1[0:256, 0:256, 0]
        I1_G = I1[0:256, 0:256, 1]
        I1_B = I1[0:256, 0:256, 2]
        I2_R = I2[0:256, 0:256, 0]
        I2_G = I2[0:256, 0:256, 1]
        I2_B = I2[0:256, 0:256, 2]
        I3_R = I3[0:256, 0:256, 0]
        I3_G = I3[0:256, 0:256, 1]
        I3_B = I4[0:256, 0:256, 2]
        I4_R = I4[0:256, 0:256, 0]
        I4_G = I4[0:256, 0:256, 1]
        I4_B = I4[0:256, 0:256, 2]

        I1_R = I1_R.clone().detach().to(dtype=torch.float32, device=device)
        I1_G = I1_G.clone().detach().to(dtype=torch.float32, device=device)
        I1_B = I1_B.clone().detach().to(dtype=torch.float32, device=device)

        I2_R = I2_R.clone().detach().to(dtype=torch.float32, device=device)
        I2_G = I2_G.clone().detach().to(dtype=torch.float32, device=device)
        I2_B = I2_B.clone().detach().to(dtype=torch.float32, device=device)

        I3_R = I3_R.clone().detach().to(dtype=torch.float32, device=device)
        I3_G = I3_G.clone().detach().to(dtype=torch.float32, device=device)
        I3_B = I3_B.clone().detach().to(dtype=torch.float32, device=device)

        I4_R = I4_R.clone().detach().to(dtype=torch.float32, device=device)
        I4_G = I4_G.clone().detach().to(dtype=torch.float32, device=device)
        I4_B = I4_B.clone().detach().to(dtype=torch.float32, device=device)

        Or1_R = MyAdjointOperatorPropagation(I1_R.cuda(), H1.cuda()).cpu().numpy()
        Or1_G = MyAdjointOperatorPropagation(I1_G.cuda(), H1.cuda()).cpu().numpy()
        Or1_B = MyAdjointOperatorPropagation(I1_B.cuda(), H1.cuda()).cpu().numpy()

        Or2_R = MyAdjointOperatorPropagation(I2_R.cuda(), H2.cuda()).cpu().numpy()
        Or2_G = MyAdjointOperatorPropagation(I2_G.cuda(), H2.cuda()).cpu().numpy()
        Or2_B = MyAdjointOperatorPropagation(I2_B.cuda(), H2.cuda()).cpu().numpy()

        Or3_R = MyAdjointOperatorPropagation(I3_R.cuda(), H3.cuda()).cpu().numpy()
        Or3_G = MyAdjointOperatorPropagation(I3_G.cuda(), H3.cuda()).cpu().numpy()
        Or3_B = MyAdjointOperatorPropagation(I3_B.cuda(), H3.cuda()).cpu().numpy()

        Or4_R = MyAdjointOperatorPropagation(I4_R.cuda(), H4.cuda()).cpu().numpy()
        Or4_G = MyAdjointOperatorPropagation(I4_G.cuda(), H4.cuda()).cpu().numpy()
        Or4_B = MyAdjointOperatorPropagation(I4_B.cuda(), H4.cuda()).cpu().numpy()

        def normalize_image(image):
            return (image - np.min(image)) / (np.max(image) - np.min(image))

        Or1_R = normalize_image(Or1_R)
        Or1_G = normalize_image(Or1_G)
        Or1_B = normalize_image(Or1_B)

        Or2_R = normalize_image(Or2_R)
        Or2_G = normalize_image(Or2_G)
        Or2_B = normalize_image(Or2_B)

        Or3_R = normalize_image(Or3_R)
        Or3_G = normalize_image(Or3_G)
        Or3_B = normalize_image(Or3_B)

        Or4_R = normalize_image(Or4_R)
        Or4_G = normalize_image(Or4_G)
        Or4_B = normalize_image(Or4_B)

        # 合并通道
        Or1 = np.stack((Or1_R, Or1_G, Or1_B), axis=-1)
        Or2 = np.stack((Or2_R, Or2_G, Or2_B), axis=-1)
        Or3 = np.stack((Or3_R, Or3_G, Or3_B), axis=-1)
        Or4 = np.stack((Or4_R, Or4_G, Or4_B), axis=-1)

        img_all = np.stack((Or1_R, Or1_G, Or1_B, Or2_R, Or2_G, Or2_B, Or3_R, Or3_G, Or3_B, Or4_R, Or4_G, Or4_B), axis=2)
        return img_all.transpose(2, 0, 1)