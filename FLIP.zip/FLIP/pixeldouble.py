import numpy as np
import matplotlib.pyplot as plt
import math
import cv2

def pixel(img):
    max_1 = img.max()
    img = img[:, :] / max_1
    img = np.array(img, dtype=float)
    guibi = np.zeros((256, 256), dtype=float)  # 输出图像大小为256×256
    inx = -1
    for i in range(0, 512, 2):  # 采样间隔为2
        inx = inx + 1
        iny = -1
        for j in range(0, 512, 2):  # 采样间隔为2
            iny = iny + 1
            patch = img[i:i+2, j:j+2]  # 采样块大小为2×2
            mean = np.sum(patch) / 4  # 计算均值
            guibi[inx, iny] = mean
    return guibi


def pixel2(img):
    max_1 = img.max()
    min_1 = img.min()
    img = (img[:, :, :] - min_1) / (max_1 - min_1)  # 归一化
    img = np.array(img, dtype=float)
    guibi = np.zeros((256, 256, 3), dtype=float)  # 输出图像大小为256×256
    for k in range(0, 3):  # 遍历每个通道
        inx = -1
        for i in range(0, 512, 2):  # 采样间隔为2
            inx = inx + 1
            iny = -1
            for j in range(0, 512, 2):  # 采样间隔为2
                iny = iny + 1
                patch = img[i:i+2, j:j+2, k]  # 采样块大小为2×2
                mean = np.sum(patch) / 4  # 计算均值
                guibi[inx, iny, k] = mean
    return guibi


def pixel_2(img):
    max_1 = img.max()
    min_1 = img.min()
    img = (img[:, :, :] - min_1) / (max_1 - min_1)  # 归一化
    img = np.array(img, dtype=float)
    guibi = np.zeros((256, 256, 3), dtype=float)  # 输出图像大小为256×256
    for k in range(0, 3):  # 遍历每个通道
        inx = -1
        for i in range(0, 512, 2):  # 采样间隔为2
            inx = inx + 1
            iny = -1
            for j in range(0, 512, 2):  # 采样间隔为2
                iny = iny + 1
                patch = img[i:i+2, j:j+2, k]  # 采样块大小为2×2
                mean = np.sum(patch) / 4  # 计算均值
                guibi[inx, iny, k] = mean
    return guibi