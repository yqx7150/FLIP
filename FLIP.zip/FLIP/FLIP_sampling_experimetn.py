from pixel import pixel, pixel3, pixel_3
from dataclasses import dataclass, field
import matplotlib.pyplot as plt
import io
import csv
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
import importlib
import os
import functools
import itertools
import torch
from losses import get_optimizer
from models.ema import ExponentialMovingAverage

import torch.nn as nn
import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_gan as tfgan
import tqdm
import io
import likelihood
from utils import restore_checkpoint
sns.set(font_scale=2)
sns.set(style="whitegrid")
import cv2
import models
from models import utils as mutils
from models import ncsnv2
from models import ncsnpp
from models import ddpm as ddpm_model
from models import layerspp
from models import layers
from models import normalization
import FLIP_reconstruction_experiment
from likelihood import get_likelihood_fn
from sde_lib import VESDE, VPSDE, subVPSDE
from FLIP_reconstruction_experiment import (ReverseDiffusionPredictor,
                      LangevinCorrector, 
                      EulerMaruyamaPredictor, 
                      AncestralSamplingPredictor, 
                      NoneCorrector, 
                      NonePredictor,
                      AnnealedLangevinDynamics)
import datasets
import scipy.io as io
from operator_fza import forward,backward,forward_torch,backward_torch
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import time

time_begin = time.time()
# @title Load the score-based model
##########################################################欠采样模型（12通道）#######################################################################################
sde = 'VESDE'  # @param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
if sde.lower() == 'vesde':
    from configs.ve import church_ncsnpp_continuous_qian12tongdao as configs

    # ckpt_filename = '/home/y/PycharmProjects/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-qian96new.pth'  # (9:(20.2,0.5)
    # ckpt_filename = '/home/y/PycharmProjects/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan-Z1220.pth'
    ckpt_filename = '/home/nd/pycharm_project/FZA_Berkman/checkpoints-meta-gai/checkpoints-meta-gai/checkpoint-BP-qian12tongdao-Z1220.pth'
    config = configs.get_config()
    sde = VESDE(sigma_min=config.model.sigma_min, sigma_max=config.model.sigma_max, N=config.model.num_scales)
    sampling_eps = 1e-5

batch_size = 1  # 64#@param {"type":"integer"}
config.training.batch_size = batch_size
config.eval.batch_size = batch_size

random_seed = 0  # @param {"type": "integer"}

sigmas = mutils.get_sigmas(config)
scaler = datasets.get_data_scaler(config)
inverse_scaler = datasets.get_data_inverse_scaler(config)
score_model = mutils.create_model(config)

optimizer = get_optimizer(config, score_model.parameters())
ema = ExponentialMovingAverage(score_model.parameters(),decay=config.model.ema_rate)
state = dict(step=0, optimizer=optimizer,model=score_model, ema=ema)

state = restore_checkpoint(ckpt_filename, state, config.device)

ema.copy_to(score_model.parameters())
############################################################全采样模型（3通道）######################################################################################################
sde_quan_12tongdao = 'VESDE' #@param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
if sde_quan_12tongdao.lower() == 'vesde':
  from configs.ve import church_ncsnpp_continuous_qian12tongdao as configs_quan12tongdao
  # ckpt_filename_quan = '/home/y/PycharmProjects/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan3tongdao-Z1220.pth' #(9:(20.2,0.5)
  # ckpt_filename_quan = '/home/y/PycharmProjects/FZA_Berkman/checkpoints/checkpoint_9.pth'  # (9:(20.2,0.5)
  ckpt_filename_quan = '/home/nd/pycharm_project/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan-Z1220.pth'
  config_quan_12tongdao = configs_quan12tongdao.get_config()
  sde_quan_12tongdao = VESDE(sigma_min=config_quan_12tongdao.model.sigma_min, sigma_max=config_quan_12tongdao.model.sigma_max, N=config_quan_12tongdao.model.num_scales)
  sampling_eps = 1e-5


batch_size =  1 #64#@param {"type":"integer"}
config_quan_12tongdao.training.batch_size = batch_size
config_quan_12tongdao.eval.batch_size = batch_size

random_seed = 0 #@param {"type": "integer"}

sigmas_quan = mutils.get_sigmas(config_quan_12tongdao)
scaler_quan = datasets.get_data_scaler(config_quan_12tongdao)
inverse_scaler_quan = datasets.get_data_inverse_scaler(config_quan_12tongdao)
score_model_quan = mutils.create_model(config_quan_12tongdao)

optimizer_quan = get_optimizer(config_quan_12tongdao, score_model_quan.parameters())
ema_quan = ExponentialMovingAverage(score_model_quan.parameters(), decay=config_quan_12tongdao.model.ema_rate)
state_quan = dict(step=0, optimizer=optimizer_quan,model=score_model_quan, ema=ema_quan)
state_quan = restore_checkpoint(ckpt_filename_quan, state_quan, config_quan_12tongdao.device)

ema_quan.copy_to(score_model_quan.parameters())
######################################################################################################################################################

# @title PC inpainting

predictor = ReverseDiffusionPredictor  # @param ["EulerMaruyamaPredictor", "AncestralSamplingPredictor", "ReverseDiffusionPredictor", "None"] {"type": "raw"}
corrector = LangevinCorrector  # @param ["LangevinCorrector", "AnnealedLangevinDynamics", "None"] {"type": "raw"}

predictor_quan = ReverseDiffusionPredictor   # @param ["EulerMaruyamaPredictor", "AncestralSamplingPredictor", "ReverseDiffusionPredictor", "None"] {"type": "raw"}
corrector_quan = LangevinCorrector  # @param ["LangevinCorrector", "AnnealedLangevinDynamics", "None"] {"type": "raw"}

snr = snr_quan = 0.16  # @param {"type": "number"}
n_steps = n_steps_quan = 1  # @param {"type": "integer"}
probability_flow = probability_flow_quan = False  # @param {"type": "boolean"}

psnr_result=[ ]
ssim_result=[ ]
list_img = []

for i in range(1, 4):
    img_test = io.loadmat(f'/home/nd/pycharm_project/MLDM_I/LSUN_church_img/{i}_original.mat')['Im'] #I_padded
    list_img.append(img_test)

for m in range(0, 4):
    for j in range(0,1,1):
      img = io.loadmat(f'/home/nd/pycharm_project/MLDM_I/LSUN_church_img/{m + 1}_original.mat')['Im']  # I_padded

    #######################################################################################################

      img_ob_b = cv2.imread(f'E:\桌面\FLIP\input\exp\{m + 1}.png', -1)

      img_ob_g = cv2.imread(f'E:\桌面\FLIP\input\exp\{m + 1}.png', -1)

      img_ob_r = cv2.imread(f'E:\桌面\FLIP\input\exp\{m + 1}.png', -1)


      img_ob_1=np.stack((img_ob_r[:,:],img_ob_g[:,:],img_ob_b[:,:]),axis=2)


      img_ob1 = img_ob_1[994:1762,700:1468,:]
      img_ob2 = img_ob_1[1000:1768,2446:3214,:]
      img_ob3 = img_ob_1[2156:2924,701:1469,:]
      img_ob4 = img_ob_1[2159:2927,2446:3214,:]

      img_ob1 = pixel3(img_ob1)
      img_ob2 = pixel3(img_ob2)
      img_ob3 = pixel3(img_ob3)
      img_ob4 = pixel3(img_ob4)

      img_ob1[:,:,0]=img_ob1[:,:,0]
      img_ob1[:,:,1]=img_ob1[:,:,1]
      img_ob1[:,:,2]=img_ob1[:,:,2]
      img_ob2[:,:,0]=img_ob2[:,:,0]
      img_ob2[:,:,1]=img_ob2[:,:,1]
      img_ob2[:,:,2]=img_ob2[:,:,2]
      img_ob3[:,:,0]=img_ob3[:,:,0]
      img_ob3[:,:,1]=img_ob3[:,:,1]
      img_ob3[:,:,2]=img_ob3[:,:,2]
      img_ob4[:,:,0]=img_ob4[:,:,0]
      img_ob4[:,:,1]=img_ob4[:,:,1]
      img_ob4[:,:,2]=img_ob4[:,:,2]

      # 修改图像数据
      img_ob1[:, :, 0] = np.clip(img_ob1[:, :, 0], 0, 1)
      img_ob1[:, :, 1] = np.clip(img_ob1[:, :, 1], 0, 1)
      img_ob1[:, :, 2] = np.clip(img_ob1[:, :, 2] , 0, 1)

      img_ob2[:, :, 0] = np.clip(img_ob2[:, :, 0] , 0, 1)
      img_ob2[:, :, 1] = np.clip(img_ob2[:, :, 1] , 0, 1)
      img_ob2[:, :, 2] = np.clip(img_ob2[:, :, 2] , 0, 1)

      img_ob3[:, :, 0] = np.clip(img_ob3[:, :, 0], 0, 1)
      img_ob3[:, :, 1] = np.clip(img_ob3[:, :, 1], 0, 1)
      img_ob3[:, :, 2] = np.clip(img_ob3[:, :, 2], 0, 1)

      img_ob4[:, :, 0] = np.clip(img_ob4[:, :, 0], 0, 1)
      img_ob4[:, :, 1] = np.clip(img_ob4[:, :, 1], 0, 1)
      img_ob4[:, :, 2] = np.clip(img_ob4[:, :, 2] , 0, 1)


      # 对每个通道进行归一化
      def normalize_channel(channel):
          min_val = channel.min()
          max_val = channel.max()
          range_val = max_val - min_val
          if range_val == 0:
              return channel  # 防止除以零
          return (channel - min_val) / range_val


      img_ob1 = np.stack([normalize_channel(img_ob1[:, :, i]) for i in range(3)], axis=2)
      img_ob2 = np.stack([normalize_channel(img_ob2[:, :, i]) for i in range(3)], axis=2)
      img_ob3 = np.stack([normalize_channel(img_ob3[:, :, i]) for i in range(3)], axis=2)
      img_ob4 = np.stack([normalize_channel(img_ob4[:, :, i]) for i in range(3)], axis=2)

      ########################################################################################################################
      img = torch.from_numpy(img).permute(2,0,1).unsqueeze(0).cuda()

      img_ob1=torch.from_numpy(img_ob1).cuda()
      img_ob2=torch.from_numpy(img_ob2).cuda()
      img_ob3=torch.from_numpy(img_ob3).cuda()
      img_ob4=torch.from_numpy(img_ob4).cuda()

      dp=0.0038*3
      di=3
      z1=400
      r1=0.3
      M=di/z1
      ri=(1+M)*r1

      NX,NY=256,256

      fu_max,fv_max=0.5/dp,0.5/dp
      du,dv=2*fu_max/NX,2*fv_max/NY
      u,v=np.mgrid[-fu_max:fu_max:du,-fv_max:fv_max:dv]
      u=u.T
      v=v.T
      # H1=1j*(np.exp(-1j*(np.dot(np.pi,ri**2))*(u**2+v**2)))
      # H2=1j*(np.exp(-1j*(np.dot(np.pi,ri**2))*(u**2+v**2)+1j*0.5*np.pi))
      # H3=1j*(np.exp(-1j*(np.dot(np.pi, ri**2))*(u** 2+v**2)+1j*1*np.pi))
      # H4=1j*(np.exp(-1j*(np.dot(np.pi, ri**2))*(u** 2+v**2)+1j*1.5*np.pi))

      H1 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2)))
      H2 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.25 * np.pi))
      H3 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.5 * np.pi))
      H4 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.75 * np.pi))

      H1=np.array(H1,dtype=np.complex128)
      H2=np.array(H2,dtype=np.complex128)
      H3=np.array(H3,dtype=np.complex128)
      H4=np.array(H4,dtype=np.complex128)

      psnr_max_1=0
      for i in range(1):
          print('##################' + str(i) + '#######################')
          img_size = config.data.image_size
          channels = config.data.num_channels = 12
          channels_quan = 3
          shape = (batch_size, channels, img_size, img_size)
          shape_quan = (batch_size, channels_quan, img_size, img_size)

          sampling_fn = MLDM_reconstruction_experiment.get_pc_sampler(
              sde, sde_quan_12tongdao, shape, shape, predictor, corrector,
              inverse_scaler, snr, n_steps=n_steps,
              probability_flow=probability_flow,
              continuous=config.training.continuous,
              eps=sampling_eps, device=config.device)

          x_quan, psnr_max, ssim_max = sampling_fn(score_model, score_model_quan, img, H1, H2, H3, H4, img_ob1, img_ob2,
                                                   img_ob3, img_ob4)

          x_quan_min = x_quan.min()
          x_quan_max = x_quan.max()
          x_quan = (x_quan - x_quan_min) / (x_quan_max - x_quan_min)

          print("x_quan.shape =", x_quan.shape)

          # x_np = x_quan.squeeze(0).permute(1, 2, 0).cpu().numpy()

          x_np = x_quan  # 如果后面只是要保存或可视化
          x_np = np.clip(x_np * 255, 0, 255).astype(np.float32)

          # 定义保存目录路径
          save_dir = '/home/nd/Pycharm_projects/FZA_Berkman/xiaohushice'
          # 递归创建目录（如果不存在），exist_ok=True避免重复创建时报错
          os.makedirs(save_dir, exist_ok=True)

          # 拼接完整保存路径（确保路径正确指向该目录）
          save_path = os.path.join(save_dir, f'image{m + 1}_{psnr_max:.2f}_{ssim_max:.3f}.png')
          # 保存图像
          # cv2.imwrite(save_path, cv2.cvtColor(x_np, cv2.COLOR_RGB2BGR))
          cv2.imwrite(save_path, x_np)  # 直接保存，不转换颜色通道

          psnr_result.append(psnr_max)
          ssim_result.append(ssim_max)

          time_end = time.time()
          print('time:', time_end - time_begin)




