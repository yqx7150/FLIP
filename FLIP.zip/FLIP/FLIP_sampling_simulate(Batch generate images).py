# FLIP_sampling_simulate（多组）.py
from pixel import pixel, pixel3, pixel_3
from dataclasses import dataclass, field
import matplotlib.pyplot as plt
import io
import csv
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
import importlib
import os
import functools
import itertools
import torch
from losses import get_optimizer
from models.ema import ExponentialMovingAverage

import imageio          # 保留，但不再用于 .mat
import torch.nn as nn
import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_gan as tfgan
import tqdm
import io
import likelihood
from utils import restore_checkpoint

from scipy.optimize import minimize
from scipy.ndimage import convolve
import matplotlib.pyplot as plt
from skimage import io, img_as_float

sns.set(font_scale=2)
sns.set(style="whitegrid")
import cv2
import models
from models import utils as mutils
from models import ncsnv2
from models import ncsnpp
from models import ddpm as ddpm_model
from models import layerspp
from models import layers
from models import normalization
import FLIP_reconstruction_simulate
from likelihood import get_likelihood_fn
from sde_lib import VESDE, VPSDE, subVPSDE
from FLIP_reconstruction_simulate import (ReverseDiffusionPredictor,
                                             LangevinCorrector,
                                             EulerMaruyamaPredictor,
                                             AncestralSamplingPredictor,
                                             NoneCorrector,
                                             NonePredictor,
                                             AnnealedLangevinDynamics)
import datasets
import scipy.io as io        # 用于正确读取 .mat
from operator_fza import forward, backward, forward_torch, backward_torch
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import time

time_begin = time.time()

# @title Load the score-based model
##########################################################欠采样模型（12通道）#######################################################################################
sde = 'VESDE'  # @param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
if sde.lower() == 'vesde':
    from configs.ve import church_ncsnpp_continuous_qian12tongdao as configs
    ckpt_filename = '/home/qgl/桌面/FZA_Berkman/checkpoints-meta-gai/checkpoints-meta-gai/checkpoint-BP-qian12tongdao-Z1220.pth'
    config = configs.get_config()
    sde = VESDE(sigma_min=config.model.sigma_min, sigma_max=config.model.sigma_max, N=config.model.num_scales)
    sampling_eps = 1e-5

batch_size = 1
config.training.batch_size = batch_size
config.eval.batch_size = batch_size
random_seed = 0

sigmas = mutils.get_sigmas(config)
scaler = datasets.get_data_scaler(config)
inverse_scaler = datasets.get_data_inverse_scaler(config)
score_model = mutils.create_model(config)

optimizer = get_optimizer(config, score_model.parameters())
ema = ExponentialMovingAverage(score_model.parameters(), decay=config.model.ema_rate)
state = dict(step=0, optimizer=optimizer, model=score_model, ema=ema)
state = restore_checkpoint(ckpt_filename, state, config.device)
ema.copy_to(score_model.parameters())

############################################################全采样模型（12通道）######################################################################################################
sde_quan_12tongdao = 'VESDE'
if sde_quan_12tongdao.lower() == 'vesde':
    from configs.ve import church_ncsnpp_continuous_qian12tongdao as configs_quan12tongdao
    ckpt_filename_quan = '/home/qgl/桌面/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan-Z1220.pth'
    config_quan_12tongdao = configs_quan12tongdao.get_config()
    sde_quan_12tongdao = VESDE(sigma_min=config_quan_12tongdao.model.sigma_min,
                               sigma_max=config_quan_12tongdao.model.sigma_max,
                               N=config_quan_12tongdao.model.num_scales)
    sampling_eps = 1e-5

batch_size = 1
config_quan_12tongdao.training.batch_size = batch_size
config_quan_12tongdao.eval.batch_size = batch_size
random_seed = 0

sigmas_quan = mutils.get_sigmas(config_quan_12tongdao)
scaler_quan = datasets.get_data_scaler(config_quan_12tongdao)
inverse_scaler_quan = datasets.get_data_inverse_scaler(config_quan_12tongdao)
score_model_quan = mutils.create_model(config_quan_12tongdao)

optimizer_quan = get_optimizer(config_quan_12tongdao, score_model_quan.parameters())
ema_quan = ExponentialMovingAverage(score_model_quan.parameters(), decay=config_quan_12tongdao.model.ema_rate)
state_quan = dict(step=0, optimizer=optimizer_quan, model=score_model_quan, ema=ema_quan)
state_quan = restore_checkpoint(ckpt_filename_quan, state_quan, config_quan_12tongdao.device)
ema_quan.copy_to(score_model_quan.parameters())

# @title PC inpainting
predictor = ReverseDiffusionPredictor
corrector = LangevinCorrector
predictor_quan = ReverseDiffusionPredictor
corrector_quan = LangevinCorrector
snr = snr_quan = 0.16
n_steps = n_steps_quan = 1
probability_flow = probability_flow_quan = False

psnr_result = []
ssim_result = []

# 修正：用 scipy.io 读 .mat，而不是 imageio
list_img = []
for i in range(1, 53):
    img_test = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/仿真数据集（200）/{i}_original.mat')['Im']  # I_padded
    # img_test = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/小卷积96保真图/{i}_original.mat')['Im']  # I_padded
    list_img.append(img_test)

for m in range(len(list_img)):
    for j in range(0, 1, 1):
        img = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/仿真数据集（200）/{m}_original.mat')['Im']  # I_padded
        img_ob1 = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/仿真数据集（200）/{m}_80encoded_phase_0.00pi.mat')['I_padded']#I11
        img_ob2 = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/仿真数据集（200）/{m}_80encoded_phase_0.25pi.mat')['I_padded']#I22
        img_ob3 = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/仿真数据集（200）/{m}_80encoded_phase_0.50pi.mat')['I_padded']#I33
        img_ob4 = io.loadmat(f'/home/qgl/桌面/FZA_Berkman/仿真数据集（200）/{m}_80encoded_phase_0.75pi.mat')['I_padded']#I44
        img = torch.from_numpy(img).permute(2, 0, 1).unsqueeze(0).cuda()
        img_ob1 = torch.from_numpy(img_ob1).cuda()
        img_ob2 = torch.from_numpy(img_ob2).cuda()
        img_ob3 = torch.from_numpy(img_ob3).cuda()
        img_ob4 = torch.from_numpy(img_ob4).cuda()
        dp = 0.014
        di = 3
        z1 = 200
        r1 = 0.23
        M = di / z1
        ri = (1 + M) * r1

        NX, NY = 256, 256
        fu_max, fv_max = 0.5 / dp, 0.5 / dp
        du, dv = 2 * fu_max / NX, 2 * fv_max / NY
        u, v = np.mgrid[-fu_max:fu_max:du, -fv_max:fv_max:dv]
        u = u.T
        v = v.T

        H1 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2)))
        H2 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.25 * np.pi))
        H3 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.5 * np.pi))
        H4 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.75 * np.pi))

        H1 = np.array(H1, dtype=np.complex128)
        H2 = np.array(H2, dtype=np.complex128)
        H3 = np.array(H3, dtype=np.complex128)
        H4 = np.array(H4, dtype=np.complex128)

        for i in range(1):
            print('##################' + str(i) + '#######################')
            img_size = config.data.image_size
            channels = config.data.num_channels = 12
            channels_quan = 3
            shape = (batch_size, channels, img_size, img_size)
            shape_quan = (batch_size, channels_quan, img_size, img_size)

            sampling_fn = MLDM_reconstruction_simulate.get_pc_sampler(
                sde, sde_quan_12tongdao, shape, shape, predictor, corrector,
                inverse_scaler, snr, n_steps=n_steps,
                probability_flow=probability_flow,
                continuous=config.training.continuous,
                eps=sampling_eps, device=config.device)

            x_quan, psnr_max, ssim_max = sampling_fn(score_model, score_model_quan, img, H1, H2, H3, H4, img_ob1, img_ob2, img_ob3, img_ob4)

            x_quan_min = x_quan.min()
            x_quan_max = x_quan.max()
            x_quan = (x_quan - x_quan_min) / (x_quan_max - x_quan_min)

            print("x_quan.shape =", x_quan.shape)

            # x_np = x_quan.squeeze(0).permute(1, 2, 0).cpu().numpy()

            x_np = x_quan  # 如果后面只是要保存或可视化
            x_np = np.clip(x_np * 255, 0, 255).astype(np.float32)

            # 定义保存目录路径
            save_dir = '/home/qgl/桌面/FZA_Berkman/大卷积96保真图'
            # 递归创建目录（如果不存在），exist_ok=True避免重复创建时报错
            os.makedirs(save_dir, exist_ok=True)

            # 拼接完整保存路径（确保路径正确指向该目录）
            save_path = os.path.join(save_dir, f'image{m+1}_{psnr_max:.2f}_{ssim_max:.3f}.png')
            # 保存图像
            # cv2.imwrite(save_path, cv2.cvtColor(x_np, cv2.COLOR_RGB2BGR))
            cv2.imwrite(save_path, x_np)  # 直接保存，不转换颜色通道


            psnr_result.append(psnr_max)
            ssim_result.append(ssim_max)

            time_end = time.time()
            print('time:', time_end - time_begin)
