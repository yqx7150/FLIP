import ml_collections
import torch


def get_default_configs():
  config = ml_collections.ConfigDict()
  # training
  config.training = training = ml_collections.ConfigDict()
  config.training.batch_size = 2#64
  training.n_iters = 2400001
  training.snapshot_freq = 300000
  training.log_freq = 1
  training.eval_freq = 100
  ## store additional checkpoints for preemption in cloud computing environments
  training.snapshot_freq_for_preemption = 5000
  ## produce samples at each snapshot.
  training.snapshot_sampling = True
  training.likelihood_weighting = False
  training.continuous = True
  training.reduce_mean = False

  # sampling
  config.sampling = sampling = ml_collections.ConfigDict()
  sampling.n_steps_each = 1
  sampling.noise_removal = True
  sampling.probability_flow = False
  sampling.snr = 0.075

  # evaluation
  config.eval = evaluate = ml_collections.ConfigDict()
  evaluate.begin_ckpt = 50
  evaluate.end_ckpt = 96
  evaluate.batch_size = 512
  evaluate.enable_sampling = True
  evaluate.num_samples = 50000
  evaluate.enable_loss = True
  evaluate.enable_bpd = False
  evaluate.bpd_dataset = 'test'

  # data
  config.data = data = ml_collections.ConfigDict()
  data.dataset = 'LSUN'
  data.image_size = 256
  data.random_flip = True
  data.uniform_dequantization = False
  data.centered = False
  data.num_channels = 3

  # model
  config.model = model = ml_collections.ConfigDict()
  model.sigma_max =0.6#378 #680
  model.sigma_min =0.01
  model.num_scales =1000#2000
  model.beta_min = 0.1
  model.beta_max = 20.
  model.dropout = 0.
  model.embedding_type = 'fourier'

  # optimization
  config.optim = optim = ml_collections.ConfigDict()
  optim.weight_decay = 0
  optim.optimizer = 'Adam'
  optim.lr = 2e-4
  optim.beta1 = 0.9
  optim.eps = 1e-8
  optim.warmup = 5000
  optim.grad_clip = 1.

  config.seed = 42
  config.device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')

  return config



"""
这段 Python 代码定义了一个函数 get_default_configs ，用于返回一个包含各种配置参数的 ml_collections.ConfigDict 对象。
以下是对每个配置部分的简要说明：
training：
batch_size：训练的批处理大小。
n_iters：训练的迭代次数。
snapshot_freq：保存模型检查点的频率。
log_freq：记录训练日志的频率。
eval_freq：评估模型的频率。
snapshot_freq_for_preemption：在云计算环境中为防止中断而额外保存检查点的频率。
snapshot_sampling：在保存检查点时是否进行采样。
likelihood_weighting：是否使用似然加权。
continuous：训练是否连续。
reduce_mean：是否进行均值归约。
sampling：
n_steps_each：每次采样的步数。
noise_removal：是否进行噪声去除。
probability_flow：是否为概率流。
snr：信号噪声比。
evaluation：
begin_ckpt：评估开始的检查点索引。
end_ckpt：评估结束的检查点索引。
batch_size：评估时的批处理大小。
enable_sampling：是否启用采样评估。
num_samples：采样数量。
enable_loss：是否启用损失评估。
enable_bpd：是否启用位/像素损失（bit-per-pixel loss）评估。
bpd_dataset：用于位/像素损失评估的数据集。
data：
dataset：使用的数据集。
image_size：图像大小。
random_flip：是否随机翻转图像。
uniform_dequantization：是否进行均匀反量化。
centered：数据是否居中。
num_channels：图像的通道数。
model：
sigma_max：最大的标准差。
sigma_min：最小的标准差。
num_scales：尺度数量。
beta_min：最小的 beta 值。
beta_max：最大的 beta 值。
dropout：辍学率。
embedding_type：嵌入类型。
optim：
weight_decay：权重衰减。
optimizer：优化器类型。
lr：学习率。
beta1：Adam 优化器的第一个动量参数。
eps：数值稳定性的小常数。
warmup：学习率预热的步数。
grad_clip：梯度裁剪的阈值。
config.seed 用于设置随机数种子，config.device 用于指定设备（如果有可用的 GPU 则为 CUDA 设备，否则为 CPU 设备）。
"""