from pixel import pixel, pixel3, pixel_3
from dataclasses import dataclass, field
import matplotlib.pyplot as plt
import io
import csv
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
import importlib
import os
import functools
import itertools
import torch
from losses import get_optimizer
from models.ema import ExponentialMovingAverage

import torch.nn as nn
import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_gan as tfgan
import tqdm
import io
import likelihood
from utils import restore_checkpoint


from scipy.optimize import minimize
from scipy.ndimage import convolve
import matplotlib.pyplot as plt
from skimage import io, img_as_float

sns.set(font_scale=2)
sns.set(style="whitegrid")
import cv2
import models
from models import utils as mutils
from models import ncsnv2
from models import ncsnpp
from models import ddpm as ddpm_model
from models import layerspp
from models import layers
from models import normalization
import FLIP_reconstruction_simulate
from likelihood import get_likelihood_fn
from sde_lib import VESDE, VPSDE, subVPSDE
from FLIP_reconstruction_simulate import (ReverseDiffusionPredictor,
                                          LangevinCorrector,
                                          EulerMaruyamaPredictor,
                                          AncestralSamplingPredictor,
                                          NoneCorrector,
                                          NonePredictor,
                                          AnnealedLangevinDynamics)
# from create_mask import create_mask_r_bian, create_mask_g_bian, create_mask_b_bian
import datasets
import scipy.io as io
from operator_fza import forward, backward, forward_torch, backward_torch
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import time

time_begin = time.time()
# @title Load the score-based model
##########################################################欠采样模型（12通道）#######################################################################################
sde = 'VESDE'  # @param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
if sde.lower() == 'vesde':
    from configs.ve import church_ncsnpp_continuous_qian12tongdao as configs

    # ckpt_filename = '/home/y/PycharmProjects/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-qian96new.pth'  # (9:(20.2,0.5)
    # ckpt_filename = '/home/y/PycharmProjects/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan-Z1220.pth'
    ckpt_filename = '/home/nd/pycharm_project/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-qian12tongdao-Z1220.pth'
    config = configs.get_config()
    sde = VESDE(sigma_min=config.model.sigma_min, sigma_max=config.model.sigma_max, N=config.model.num_scales)
    sampling_eps = 1e-5

batch_size = 1  # 64#@param {"type":"integer"}
config.training.batch_size = batch_size
config.eval.batch_size = batch_size

random_seed = 0  # @param {"type": "integer"}

sigmas = mutils.get_sigmas(config)
scaler = datasets.get_data_scaler(config)
inverse_scaler = datasets.get_data_inverse_scaler(config)
score_model = mutils.create_model(config)

optimizer = get_optimizer(config, score_model.parameters())
ema = ExponentialMovingAverage(score_model.parameters(),decay=config.model.ema_rate)
state = dict(step=0, optimizer=optimizer,model=score_model, ema=ema)

state = restore_checkpoint(ckpt_filename, state, config.device)

ema.copy_to(score_model.parameters())
############################################################全采样模型（3通道）######################################################################################################
sde_quan_12tongdao = 'VESDE' #@param ['VESDE', 'VPSDE', 'subVPSDE'] {"type": "string"}
if sde_quan_12tongdao.lower() == 'vesde':
  from configs.ve import church_ncsnpp_continuous_qian12tongdao as configs_quan12tongdao
  # ckpt_filename_quan = '/home/y/PycharmProjects/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan3tongdao-Z1220.pth' #(9:(20.2,0.5)
  # ckpt_filename_quan = '/home/y/PycharmProjects/FZA_Berkman/checkpoints/checkpoint_9.pth'  # (9:(20.2,0.5)
  ckpt_filename_quan = '/home/nd/pycharm_project/FZA_Berkman/trained_checkpoints/checkpoints-meta-gai/checkpoint-BP-quan-Z1220.pth'
  config_quan_12tongdao = configs_quan12tongdao.get_config()
  sde_quan_12tongdao = VESDE(sigma_min=config_quan_12tongdao.model.sigma_min, sigma_max=config_quan_12tongdao.model.sigma_max, N=config_quan_12tongdao.model.num_scales)
  sampling_eps = 1e-5


batch_size =  1 #64#@param {"type":"integer"}
config_quan_12tongdao.training.batch_size = batch_size
config_quan_12tongdao.eval.batch_size = batch_size

random_seed = 0 #@param {"type": "integer"}

sigmas_quan = mutils.get_sigmas(config_quan_12tongdao)
scaler_quan = datasets.get_data_scaler(config_quan_12tongdao)
inverse_scaler_quan = datasets.get_data_inverse_scaler(config_quan_12tongdao)
score_model_quan = mutils.create_model(config_quan_12tongdao)

optimizer_quan = get_optimizer(config_quan_12tongdao, score_model_quan.parameters())
ema_quan = ExponentialMovingAverage(score_model_quan.parameters(), decay=config_quan_12tongdao.model.ema_rate)
state_quan = dict(step=0, optimizer=optimizer_quan,model=score_model_quan, ema=ema_quan)
state_quan = restore_checkpoint(ckpt_filename_quan, state_quan, config_quan_12tongdao.device)

ema_quan.copy_to(score_model_quan.parameters())
######################################################################################################################################################

# @title PC inpainting

predictor = ReverseDiffusionPredictor  # @param ["EulerMaruyamaPredictor", "AncestralSamplingPredictor", "ReverseDiffusionPredictor", "None"] {"type": "raw"}
corrector = LangevinCorrector  # @param ["LangevinCorrector", "AnnealedLangevinDynamics", "None"] {"type": "raw"}

predictor_quan = ReverseDiffusionPredictor   # @param ["EulerMaruyamaPredictor", "AncestralSamplingPredictor", "ReverseDiffusionPredictor", "None"] {"type": "raw"}
corrector_quan = LangevinCorrector  # @param ["LangevinCorrector", "AnnealedLangevinDynamics", "None"] {"type": "raw"}

snr = snr_quan = 0.16  # @param {"type": "number"}
n_steps = n_steps_quan = 1  # @param {"type": "integer"}
probability_flow = probability_flow_quan = False  # @param {"type": "boolean"}

psnr_result = []
ssim_result = []

for j in range(0, 1, 1):
    img = io.loadmat('E:\桌面\FLIP\input\sim\0_original.mat')['Im']
    img_ob1 = io.loadmat(f'E:\桌面\FLIP\input\sim\0_1encoded_phase_0.00pi.mat')['I_padded']  # I11
    img_ob2 = io.loadmat(f'E:\桌面\FLIP\input\sim\0_1encoded_phase_0.00pi.mat')['I_padded']  # I22
    img_ob3 = io.loadmat(f'E:\桌面\FLIP\input\sim\0_1encoded_phase_0.00pi.mat')['I_padded']  # I33I_padded
    img_ob4 = io.loadmat(f'E:\桌面\FLIP\input\sim\0_1encoded_phase_0.00pi.mat')['I_padded']  # I44


    img = torch.from_numpy(img).permute(2, 0, 1).unsqueeze(0).cuda()  # tensor:(1,12,256,256)
    # img_ob1 = torch.from_numpy(img_ob1).permute(2, 0, 1).unsqueeze(0).cuda()  # tensor:(1,12,256,256)

    img_ob1 = torch.from_numpy(img_ob1).cuda()
    print(img_ob1.shape)  # 推荐

    img_ob2 = torch.from_numpy(img_ob2).cuda()
    img_ob3 = torch.from_numpy(img_ob3).cuda()
    img_ob4 = torch.from_numpy(img_ob4).cuda()

    dp = 0.014
    di = 3
    z1 = 220
    r1 = 0.23
    M = di / z1
    ri = (1 + M) * r1
    NX, NY = 256, 256
    fu_max, fv_max = 0.5 / dp, 0.5 / dp
    du, dv = 2 * fu_max / NX, 2 * fv_max / NY
    u, v = np.mgrid[-fu_max:fu_max:du, -fv_max:fv_max:dv]
    u = u.T
    v = v.T

    H1 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2)))
    H2 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.25 * np.pi))
    H3 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.5 * np.pi))
    H4 = 1j * (np.exp(-1j * (np.dot(np.pi, ri ** 2)) * (u ** 2 + v ** 2) + 1j * 0.75 * np.pi))

    H1 = np.array(H1, dtype=np.complex128)
    H2 = np.array(H2, dtype=np.complex128)
    H3 = np.array(H3, dtype=np.complex128)
    H4 = np.array(H4, dtype=np.complex128)

    # print(img.shape)

    for i in range(1):
        print('##################' + str(i) + '#######################')

        img_size = config.data.image_size  # 256
        channels = config.data.num_channels = 12  # 12
        channels_quan = 3
        shape = (batch_size, channels, img_size, img_size)  # (1,12,256,256)
        shape_quan = (batch_size, channels_quan, img_size, img_size)  # (1,12,256,256)

        print(img.shape)

        sampling_fn = MLDM_reconstruction_simulate.get_pc_sampler(sde,sde_quan_12tongdao,shape,shape,predictor,
                                                                  corrector,
                                                                  inverse_scaler,snr,n_steps=n_steps,
                                                                  probability_flow=probability_flow,
                                                                  continuous=config.training.continuous,
                                                                  eps=sampling_eps, device=config.device)


        x_quan, psnr_max, ssim_max = sampling_fn(score_model,score_model_quan,img,H1,H2,H3,H4,img_ob1,img_ob2,img_ob3,img_ob4)
        # img:tensor(1,12,256,256)    H:numpy(256,256)  img_ob:tensor(256,256,3)

        x_quan_min = x_quan.min()
        x_quan_max = x_quan.max()
        x_quan = (x_quan - x_quan_min) / (x_quan_max - x_quan_min)

        cv2.imwrite('/home/nd/pycharm_project/FZA_Berkman/Reconstruct_img_test.png', x_quan * 255)
        time_end = time.time()
        print('time:', time_end - time_begin)


########################################################################################大致改好了，全部修改好后再复查一遍###################################################################################